const pages = ["dashboard","exams","questions","students","lecturers","results","reports","settings"];
const navItems = document.querySelectorAll(".nav-item");
const pageTitle = document.getElementById("pageTitle");

function showPage(page){
  pages.forEach(p=>{
    const el=document.getElementById(p+"Page");
    if(el) el.classList.toggle("hidden",p!==page);
  });
  navItems.forEach(btn=>btn.classList.toggle("active",btn.dataset.page===page));
  pageTitle.textContent=page.charAt(0).toUpperCase()+page.slice(1).replace("-", " ");
  window.scrollTo({top:0,behavior:"smooth"});
}
navItems.forEach(btn=>btn.addEventListener("click",()=>showPage(btn.dataset.page)));
document.querySelectorAll("[data-page-link]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.pageLink)));

const exams=[
 {name:"Software Engineering - Mid Term",course:"CS205",date:"25 Sep 2026",students:124,status:"Scheduled"},
 {name:"Database Management Systems",course:"CS204",date:"28 Sep 2026",students:118,status:"Live"},
 {name:"Operating Systems - Final",course:"CS206",date:"02 Oct 2026",students:125,status:"Completed"},
 {name:"Computer Networks",course:"CS207",date:"07 Oct 2026",students:106,status:"Scheduled"},
 {name:"Information Systems",course:"IS210",date:"10 Oct 2026",students:94,status:"Scheduled"}
];
const students=[
 ["Nethmi Perera","SUSL/CS/24/001","Computer Science","2","Active"],
 ["Kavindu Silva","SUSL/CS/24/018","Computer Science","2","Active"],
 ["Tharushi Fernando","SUSL/IT/23/042","Information Technology","3","Active"],
 ["Sahan Wijesinghe","SUSL/CS/25/081","Computer Science","1","Active"],
 ["Dilki Senanayake","SUSL/IT/24/055","Information Technology","2","Suspended"]
];
const lecturers=[
 ["Dr. A. Perera","aperera@sab.ac.lk","Computing","4","Active"],
 ["Ms. N. Fernando","nfernando@sab.ac.lk","Computing","3","Active"],
 ["Mr. K. Jayasinghe","kjayasinghe@sab.ac.lk","Information Systems","5","Active"],
 ["Dr. S. Bandara","sbandara@sab.ac.lk","Computing","4","Active"]
];

function badge(status){
 const cls=status.toLowerCase();
 return `<span class="badge ${cls}">${status}</span>`;
}
function renderExams(list=exams){
 document.getElementById("examTable").innerHTML=list.map((e,i)=>`<tr><td>${e.name}</td><td>${e.course}</td><td>${e.date}</td><td>${e.students}</td><td>${badge(e.status)}</td><td><button class="more" onclick="editExam(${i})">•••</button></td></tr>`).join("");
 document.getElementById("recentExams").innerHTML=list.slice(0,4).map(e=>`<tr><td>${e.name}</td><td>${e.date}</td><td>${e.students}</td><td>${badge(e.status)}</td><td><button class="more">•••</button></td></tr>`).join("");
}
function renderStudents(){
 document.getElementById("studentTable").innerHTML=students.map(s=>`<tr><td>${s[0]}</td><td>${s[1]}</td><td>${s[2]}</td><td>${s[3]}</td><td>${badge(s[4])}</td><td><button class="more">•••</button></td></tr>`).join("");
}
function renderLecturers(){
 document.getElementById("lecturerTable").innerHTML=lecturers.map(s=>`<tr><td>${s[0]}</td><td>${s[1]}</td><td>${s[2]}</td><td>${s[3]}</td><td>${badge(s[4])}</td><td><button class="more">•••</button></td></tr>`).join("");
}
renderExams(); renderStudents(); renderLecturers();

document.getElementById("examSearch").addEventListener("input",e=>{
 const q=e.target.value.toLowerCase();
 renderExams(exams.filter(x=>Object.values(x).join(" ").toLowerCase().includes(q)));
});

const modal=document.getElementById("modal"), modalTitle=document.getElementById("modalTitle"), modalSubtitle=document.getElementById("modalSubtitle"), modalFields=document.getElementById("modalFields");
function openModal(type){
 let fields="";
 const configs={
  exam:["Examination Name","Course Code","Examination Date","Duration"],
  student:["Full Name","Registration Number","Email","Programme"],
  lecturer:["Full Name","Email","Department","Assigned Courses"],
  question:["Question","Course","Question Type","Marks"],
  report:["Report Type","From Date","To Date"]
 };
 (configs[type]||configs.exam).forEach((label,i)=>{
   const isSelect=label==="Question Type"||label==="Programme"||label==="Report Type";
   fields+=`<div class="field"><label>${label}</label>${isSelect?
   `<select><option>Select ${label}</option><option>Multiple Choice</option><option>Short Answer</option><option>Essay</option></select>`:
   `<input type="${label.includes("Date")?"date":"text"}" placeholder="Enter ${label.toLowerCase()}">`}</div>`;
 });
 modalTitle.textContent=type==="exam"?"Create Examination":`Add ${type.charAt(0).toUpperCase()+type.slice(1)}`;
 modalSubtitle.textContent="Enter the required details below.";
 modalFields.innerHTML=fields; modal.classList.remove("hidden");
}
document.getElementById("modalClose").onclick=()=>modal.classList.add("hidden");
modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.add("hidden")});
document.getElementById("modalForm").addEventListener("submit",e=>{
 e.preventDefault(); modal.classList.add("hidden"); showToast("Information saved successfully."); 
 if(modalTitle.textContent==="Create Examination"){exams.unshift({name:"New Examination",course:"NEW101",date:"Pending",students:0,status:"Scheduled"});renderExams();}
});
document.getElementById("createExamBtn").onclick=()=>openModal("exam");
document.getElementById("addExam").onclick=()=>openModal("exam");
document.getElementById("addStudent").onclick=()=>openModal("student");
document.getElementById("addLecturer").onclick=()=>openModal("lecturer");
document.getElementById("addQuestion").onclick=()=>openModal("question");
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>openModal(b.dataset.action));

document.getElementById("exportResults").onclick=()=>showToast("Results report prepared for export.");
document.getElementById("notificationBtn").onclick=()=>showToast("You have 4 recent system notifications.");
document.getElementById("logoutBtn").onclick=()=>{if(confirm("Sign out of the administrator dashboard?"))showToast("Signed out successfully.");};
document.getElementById("menuBtn").onclick=()=>document.getElementById("sidebar").classList.toggle("open");
document.querySelectorAll(".save").forEach(b=>b.onclick=()=>showToast("Settings saved successfully."));
document.querySelectorAll(".report-card").forEach(b=>b.onclick=()=>showToast("Report generation started."));

function showToast(message){
 const t=document.getElementById("toast"); t.textContent=message; t.classList.add("show");
 clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>t.classList.remove("show"),2400);
}
window.editExam=i=>showToast(`Opening ${exams[i].name}`);
